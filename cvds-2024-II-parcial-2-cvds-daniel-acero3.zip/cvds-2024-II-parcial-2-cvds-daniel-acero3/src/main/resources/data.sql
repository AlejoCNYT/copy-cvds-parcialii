INSERT INTO DANIEL_ACERO (pregunta, respuesta, justificacion) VALUES ('1', 'Valor 1', 'Explicacion');
