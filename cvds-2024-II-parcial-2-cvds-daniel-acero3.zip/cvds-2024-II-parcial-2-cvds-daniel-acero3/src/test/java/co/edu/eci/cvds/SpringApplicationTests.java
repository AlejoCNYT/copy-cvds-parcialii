package co.edu.eci.cvds;

import org.springframework.boot.test.context.SpringBootTest;

/*import org.junit.jupiter.api.Test;*/

@SpringBootTest
class SpringApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
